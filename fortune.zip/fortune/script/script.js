$(".navbar-toggle").click(function() {
    $(".asdf").toggle("slow");
});



$('#my-slider').sliderPro({
    width: window.innerWidth + "px",
    height: 629,
    arrows: true,
    buttons: false,
    waitForLayers: true,
    fade: true,
    autoplay: true,
    autoScaleLayers: true,
    slideAnimationDuration: 300,




});
$(".haqqbtn").hover(function() {
    $(".sonmetn").css("display", "block");
    $(".haqqbtn").css("display", "none");
});
$(".haqqbtnson").hover(function() {
    $(".sonmetn").css("display", "none");
    $(".haqqbtn").css("display", "block");
});

$(window).scroll(function() {
    var scroll = $(window).scrollTop();

    if (scroll >= 100) {
        $("#scrollTopButton").css("display", "block");
    } else {
        $("#scrollTopButton").css("display", "none");
    }
});
$("#scrollTopButton").click(function() {
    $("html, body").animate({ scrollTop: 0 }, 800);
    return false;
});

$(".haqqimizdamenu").click(function() {
    $('html, body').animate({ scrollTop: 800 }, 800);
    return false;
});
$(".gorduyumuzislermenu").click(function() {
    $('html, body').animate({ scrollTop: 1200 }, 800);
    $('.sonmetn').css("display", "none");
    $(".haqqbtn").css("display", "block");
    return false;

});
$(".esasheyetmenu").click(function() {
    $('html, body').animate({ scrollTop: 1780 }, 800);
    $('.sonmetn').css("display", "none");
    $(".haqqbtn").css("display", "block");
    return false;

});
$(".contactmenu").click(function() {
    $('html, body').animate({ scrollTop: 1950 }, 800);
    $('.sonmetn').css("display", "none");
    $(".haqqbtn").css("display", "block");
    return false;

});
$(".haqqimizdamenu").click(function() {
    $('.sonmetn').css("display", "none");
    $(".haqqbtn").css("display", "block");
});
// $(window).scroll(function() {
//     var scroll = $(window).scrollTop();

//     if (scroll >= 2000) {
//         $(".sonmetndivi").css("display", "none");
//     }
//     // else {
//     //     $(".sonmetndivi").css("display", "block");
//     // }
// });

